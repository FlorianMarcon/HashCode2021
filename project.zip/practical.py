I delete file doing rm -rf
